using Godot;
using System;

public partial class Logo : Sprite2D
{

	private const int speed = 2;
	private Vector2 pos = Vector2.Zero;
	private const int scaling = 1;

	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		pos = new Vector2(100,200);
		Position = pos;

		int rotation = 45;
		RotationDegrees = rotation;

		Scale = new Vector2(scaling, scaling);
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		this.Position += new Vector2(speed,0);
		//this.Scale += new Vector2(scaling, scaling);
	}
}
