using Godot;
using Godot.NativeInterop;
using System;

public partial class level : Node2D
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		Godot.Sprite2D logo = this.GetNode<Godot.Sprite2D>("Logo");
		logo.RotationDegrees = 90;
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		Godot.Sprite2D logo = this.GetNode<Godot.Sprite2D>("Logo");
		logo.RotationDegrees += 5;

		if (logo.RotationDegrees > 180)
			logo.RotationDegrees = 0;
		
		if(logo.Position.X > 1000)
			logo.Position = new Vector2(0,200);
	}
}
